<!DOCTYPE html>
<html class="no-js">
<head>
<link rel="stylesheet" href="http://localhost/studip23/public/assets/stylesheets/style.css" media="screen, print">
<link rel="stylesheet" href="http://localhost/studip23/public/assets/stylesheets/header.css" media="screen, print">
</head>
<body>
		<div class="clear"></div>
        <h2 id="bd_basicsettings" class="steelgraulight">Das CASA-Plugin f&uuml;r Stud.IP</h2>
	
	Test
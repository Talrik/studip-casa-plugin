
DROP TABLE `casa_services`;
DELETE FROM `log_actions` WHERE `log_actions`.`action_id` = '8e16ef418efca51bf99536ff9c4fc01b';
DELETE FROM `log_actions` WHERE `log_actions`.`action_id` = '0934a79fb5dd0347d6b3ed893a9c3949';
DELETE FROM `log_actions` WHERE `log_actions`.`action_id` = 'f469908c2d5f71c5637c61b58506ce3c';
DELETE FROM `log_actions` WHERE `log_actions`.`action_id` = '62f5cc46b58e1862bb352499e41f7aa0';
DELETE FROM `log_actions` WHERE `log_actions`.`action_id` = '2780961516cea2fe59c8343c87534aa6';

DROP TABLE `casa_services`;
#!/usr/bin/zip
zip -r CasaPlugin .
